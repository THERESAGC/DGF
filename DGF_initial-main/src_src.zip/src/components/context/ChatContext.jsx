import { createContext, useState, useEffect } from 'react';
import { io } from 'socket.io-client';
import PropTypes from 'prop-types';

export const ChatContext = createContext();

const socket = io('http://localhost:8000'); // Adjust this URL to your server

export const ChatProvider = ({ children }) => {
  const [messages, setMessages] = useState([]);
  const [newMessage, setNewMessage] = useState('');

  useEffect(() => {
    socket.on('message', (message) => {
      setMessages((prevMessages) => [...prevMessages, message]);
    });

    return () => {
      socket.off('message');
    };
  }, []);

  const sendMessage = (message, requestId, userId, status) => {
    const messageData = {
      message,
      requestId,
      userId,
      status,
      timestamp: new Date(),
    };
    socket.emit('sendMessage', messageData);
    setMessages((prevMessages) => [...prevMessages, messageData]);
  };

  return (
    <ChatContext.Provider value={{ messages, sendMessage, newMessage, setNewMessage }}>
      {children}
    </ChatContext.Provider>
  );
};

ChatProvider.propTypes = {
  children: PropTypes.node.isRequired,
};