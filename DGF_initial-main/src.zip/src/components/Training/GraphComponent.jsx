import { Box, Typography } from "@mui/material";
import { Doughnut } from "react-chartjs-2";
import { Chart as ChartJS, ArcElement, Tooltip, Legend } from "chart.js";
import PropTypes from 'prop-types';

ChartJS.register(ArcElement, Tooltip, Legend);

const GraphComponent = ({ title, data, details }) => {
  const totalRequests = data.values.reduce((a, b) => a + b, 0);

  const chartData = {
    labels: data.labels,
    datasets: [
      {
        data: data.values,
        backgroundColor: data.colors,
        hoverBackgroundColor: data.hoverColors,
        borderWidth: 1,
      },
    ],
  };

  const chartOptions = {
    cutout: '85%', // Increase the cutout percentage to make the circumference larger
  };

  return (
    <Box 
      sx={{ 
        textAlign: "center", 
        backgroundColor: "#ebebf8fa",  // Apply the background color here
        padding: 2, 
        borderRadius: 2, 
        boxShadow: 3,
      }}
    >
      <Typography variant="h6" sx={{ mb: 2, fontWeight:'bold' }}>{title}</Typography>
      <Box 
        sx={{ 
          display: 'flex', // Use flexbox layout
          alignItems: 'center', // Center items vertically
        }}
      >
        <Box sx={{ width: 100, height: 100, marginRight: 2, position: 'relative' }}> {/* Adjust width and height */}
          <Doughnut data={chartData} options={chartOptions} />
          <Typography 
            variant="h6" 
            sx={{ 
              position: 'absolute', 
              top: '50%', 
              left: '50%', 
              transform: 'translate(-50%, -50%)' 
            }}
          >
            {totalRequests} Requests
          </Typography>
        </Box>
        <Box sx={{ textAlign: 'left' }}> {/* Align text to the left */}
          {details.map((detail, index) => {
            const [label, value] = detail.split(': ');
            return (
              <Typography key={index} variant="body1">
                {label}: <span style={{ color: data.colors[index] }}>{value}</span>
              </Typography>
            );
          })}
        </Box>
      </Box>
    </Box>
  );
};

GraphComponent.propTypes = {
  title: PropTypes.string.isRequired,
  data: PropTypes.shape({
    labels: PropTypes.arrayOf(PropTypes.string).isRequired,
    values: PropTypes.arrayOf(PropTypes.number).isRequired,
    colors: PropTypes.arrayOf(PropTypes.string).isRequired,
    hoverColors: PropTypes.arrayOf(PropTypes.string).isRequired,
  }).isRequired,
  details: PropTypes.arrayOf(PropTypes.string).isRequired,
};

export default GraphComponent;