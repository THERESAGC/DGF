import InitiateTraining from "./CapDevTrainInitiate/InitiateTraining"

const InitiateTrainingContainer = () => {
  return (
    <div>
      <InitiateTraining />
    </div>
  )
}

export default InitiateTrainingContainer
