"use client"

import { useState, useContext } from "react"
import { AppBar, Toolbar, Typography, Button, Box } from "@mui/material"
import { useNavigate } from "react-router-dom"
import AuthContext from "../Auth/AuthContext"
import AddUserModal from "./AddUserModal"
import RequestFormEditorModal from "./RequestFormEditorModal" // Import the new modal
import "./AdminHeaderBtn.css"

const AdminHeaderBtn = () => {
  const [selectedButton, setSelectedButton] = useState("Users")
  const [isUserModalOpen, setIsUserModalOpen] = useState(false)
  const [isFormEditorModalOpen, setIsFormEditorModalOpen] = useState(false) // New state for form editor modal
  const navigate = useNavigate()
  const { user } = useContext(AuthContext)

  const handleButtonClick = (button, path) => {
    setSelectedButton(button)
    if (button === "New Request Form") {
      setIsFormEditorModalOpen(true) // Open the form editor modal when clicked
    } else {
      navigate(path)
    }
  }

  const handleOpenUserModal = () => {
    setIsUserModalOpen(true)
  }

  const handleCloseUserModal = () => {
    setIsUserModalOpen(false)
  }

  const handleCloseFormEditorModal = () => {
    setIsFormEditorModalOpen(false)
  }

  return (
    <>
      <AppBar position="static" className="AdminBar">
        <Toolbar className="toolbar">
          <Box className="admin">
            {[
              { text: "Users", path: "/admin-container" },
              { text: "New Request Form", path: "" }, // Changed from 'Roles' to 'New Request Form'
            ].map((item) => (
              <Typography
                key={item.text}
                variant="h6"
                component="div"
                className={`typography ${selectedButton === item.text ? "selected" : ""}`}
                onClick={() => handleButtonClick(item.text, item.path)}
              >
                {item.text}
              </Typography>
            ))}
          </Box>
          <Box className="admin">
            <Button
              variant="contained"
              color="primary"
              className="button"
              onClick={handleOpenUserModal}
              disabled={user.role_id === 10}
            >
              Add User
            </Button>
          </Box>
        </Toolbar>
      </AppBar>
      <AddUserModal open={isUserModalOpen} onClose={handleCloseUserModal} />
      <RequestFormEditorModal open={isFormEditorModalOpen} onClose={handleCloseFormEditorModal} />{" "}
      {/* New modal component */}
    </>
  )
}

export default AdminHeaderBtn

